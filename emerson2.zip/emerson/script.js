const fogos_artificios =
  "https://gifs.eco.br/wp-content/uploads/2022/02/gifs-animados-de-fogos-de-artificio-35.gif";

const cara_triste =
  "https://i.pinimg.com/564x/7d/53/66/7d5366af7998b8335bee042c6cd9d9ec.jpg";

const valores_para_soma = document.querySelector("#soma");

// duas variaveis com valores aleatorios
let valor1 = parseInt(Math.random() * 10);
let valor2 = parseInt(Math.random() * 10);

valores_para_soma.value = valor1 + "+" + valor2;

const valor_do_usuario = document.querySelector("#resposta");

const botao = document.querySelector("#bota_enviar");

const imagem = document.querySelector("#imagem");

// --------------------- MOVIMENTO DO HEROI ---------------------
let heroi = document.getElementById("heroi");
window.onload = function () {
  let fase1 = document.createElement("fase1");
  console.log(fase1.getBoundingClientRect().height);
};

//   var change = 0;

// --------------------- FIM MOVIMENTO DO HEROI ---------------------

botao.addEventListener("click", function () {
  if (parseInt(valor_do_usuario.value) == valor1 + valor2) {
    imagem.src = fogos_artificios;
    let posicaoAuxiliar = parseInt(heroi.style.left.replace("px", ""));
    posicaoAuxiliar = posicaoAuxiliar ? posicaoAuxiliar : 0;
    const repeticao = setInterval(function () {
      let posicaoAtual = parseInt(heroi.style.left.replace("px", ""));
      posicaoAtual = posicaoAtual ? posicaoAtual : 0;
      if (posicaoAtual > 200 + posicaoAuxiliar) {
        botao.disabled = false;
        valor1 = parseInt(Math.random() * 10);
        valor2 = parseInt(Math.random() * 10);
        valores_para_soma.value = valor1 + "+" + valor2;
        imagem.src = "";
        clearInterval(repeticao);
      } else {
        heroi.style.left = posicaoAtual + 5 + "px";
        botao.disabled = true;
      }
    }, 50);
  } else {
    imagem.src = cara_triste;
  }
});
